# Simply Dark
### Dark theme for Discord Bot Maker
**Compatible DBM:** 1.3.0

![alt text](files/screen/screen.png "Logo Title Text 1")
